import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import './resultcss/result.css';

// result.css 1712
function exportHTML(emptyArr) {
  var list = [];
  var len = 0;
  var h = '30px';
  var t = "";
  var class_name;
  var dif=-1;
  var first=true;
  var html;

  for (var i = 0; i < emptyArr.length; i++) {

    t = (i*30).toString() + 'px';
    if(i!=0) dif = emptyArr[i-1].length;
    len = emptyArr[i].length;
    if(dif != len) first = true;
    else first = false;
    class_name = "subject color" + (len+1).toString();

    let names = "";

    if(len != 0) {
      for(let name of emptyArr[i]) {
        names = names + name + ",";
      }
      names = names.substring(0,names.length-1);
    }
    else {
      names = "모두 불가능한 시간!";
    }

    if(first==true) html = <><br></br><p><em>가능한 인원 수</em><span>{len.toString()}명</span></p></>;
    else html = <></>;

    list.push(
      <div class={class_name} style={{ height: h, top: t }} onClick={() => {
        alert(names);
      }}>
        {html}
      </div>
    )

  }

  return list;
}

const Result = (props) => {

  const location = useLocation();
  const emptyTimes = location.state.result;

  return (
    <>
    <div class='App'>
    <h1><em>시간을 클릭해보세요!</em></h1>
        <div id="container" class="timetable" style={{ height: '601px' }}>
          <div className='aside'></div>
          <div class="wrap" >
            <div class="tablehead" >
              <table class="tablehead">
                <tbody>
                  <tr>
                    <th></th>
                    <td>월</td>
                    <td>화</td>
                    <td>수</td>
                    <td>목</td>
                    <td>금</td>
                    <td style={{ display: 'none' }}>토</td>
                    <td style={{ display: 'none' }}>일</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="tablebody">
              <table class="tablebody" style={{ margintop: '-2px' }}>
                <tbody>
                  <tr>
                    <th>
                      <div class="times">
                        <div class="time">오전 0시</div>
                        <div class="time">오전 1시</div>
                        <div class="time">오전 2시</div>
                        <div class="time">오전 3시</div>
                        <div class="time">오전 4시</div>
                        <div class="time">오전 5시</div>
                        <div class="time">오전 6시</div>
                        <div class="time">오전 7시</div>
                        <div class="time">오전 8시</div>
                        <div class="time">오전 9시</div>
                        <div class="time">오전 10시</div>
                        <div class="time">오전 11시</div>
                        <div class="time">오후 12시</div>
                        <div class="time">오후 1시</div>
                        <div class="time">오후 2시</div>
                        <div class="time">오후 3시</div>
                        <div class="time">오후 4시</div>
                        <div class="time">오후 5시</div>
                        <div class="time">오후 6시</div>
                        <div class="time">오후 7시</div>
                        <div class="time">오후 8시</div>
                        <div class="time">오후 9시</div>
                        <div class="time">오후 10시</div>
                        <div class="time">오후 11시</div>
                      </div>
                    </th>
                    <td>
                      <div class="cols" style={{ width: '132px' }}>
                        {exportHTML(emptyTimes['Mon'])}
                      </div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid">
                        </div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td>
                      <div class="cols" style={{ width: '132px' }}>
                      {exportHTML(emptyTimes['Tue'])}
                      </div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td>
                      <div class="cols" style={{ width: '132px' }}>
                      {exportHTML(emptyTimes['Wed'])}
                      </div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td>
                      <div class="cols" style={{ width: '132px' }}>
                      {exportHTML(emptyTimes['Thu'])}
                      </div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td>
                      <div class="cols" style={{ width: '132px' }}>
                      {exportHTML(emptyTimes['Fri'])}
                      </div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td style={{ display: 'none' }}>
                      <div class="132px"></div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid">
                        </div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid">
                        </div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                    <td style={{ display: 'none' }}>
                      <div class="cols"></div>
                      <div class="grids">
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                        <div class="grid"></div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="nontimes"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Result;